import Foundation

typealias Codable = Decodable & Encodable

//MARK: Basic example of use of Decoder

let json = """
{
    "manufacturer": "Cessna",
    "model": "172 Skyhawk",
    "seats": 4
}
""".data(using: .utf8)!

struct Plane: Codable {
    var manufacturer: String 
    var model: String
    var seats: Int
}

var decoder = JSONDecoder()
let plane = try! decoder.decode(Plane.self, from: json)

print(plane)

let json2 = """
{
    "planes": [
        {
            "manufacturer": "Cessna",
            "model": "172 Skyhawk",
            "seats": 4
        },
        {
            "manufacturer": "Piper",
            "model": "PA-28 Cherokee",
            "seats": 4
        }
    ]
}
""".data(using: .utf8)

let result = try! decoder.decode([String: [Plane]].self, from: json2!)
if let planes = result["planes"] {
    for plane in planes {
        print(plane)
    }
}

//MARK: A more complex structure

struct Aircraft: Decodable {
    var identification: String
    var color: String
}

enum FlightRules: String, Decodable {
    case visual = "VFR"
    case instrument = "IFR"
}

decoder.dateDecodingStrategy = .iso8601 //for date parsing from json

struct FlightPlan: Decodable {
    
    var aircraft: Aircraft
    var route: [String]
    
    
    private var departureDates: [String: Date]
    var proposedDepartureDate: Date? {
        return departureDates["proposed"]
    }
    var actualDepartureDate: Date? {
        return departureDates["actual"]
    }
    
    var flightRules: FlightRules
    var remarks: String?
    
    private enum CodingKeys: String, CodingKey {
        case aircraft
        case route
        case departureDates = "departure_time"
        case flightRules = "flight_rules"
        case remarks
    }
}

let flightPlanJSON = """
{
    "aircraft": {
        "identification": "NA12345",
        "color": "Blue/White"
    },
    "route": ["KTTD", "KHIO"],
    "departure_time": {
        "proposed": "2018-04-27T14:15:00-0700",
        "actual": "2018-04-27T14:20:00-0700"
    },
    "flight_rules": "IFR",
    "remarks": null
}
""".data(using: .utf8)!
do {
    let plan = try decoder.decode(FlightPlan.self, from: flightPlanJSON)
    print(plan.aircraft.identification)
    print(plan.actualDepartureDate!)
} catch {
    print(error)
}

























//MARK: Example using iTunes API
struct Object: Codable {
    var feed: Feed
}

struct Feed: Codable {
    var title: String
    var id: String
    var author: Author
    var links: [[String: String]]
    var copyright: String
    var country: String
    var icon: String
    var updated: String
    var results: [Result]
}

struct Author: Codable {
    var name: String
    var uri: String
}

struct Result: Codable {
    var artistName: String
    var id: String
    var releaseDate: String
    var name: String
    var collectionName: String
    var kind: String
    var copyright: String
    var artistId: String
    var contentAdvisoryRating: String
    var artistUrl: String
    var artworkUrl100: String
    var url: String
    var genres: [Genre]
}

struct Genre: Codable {
    var genreId: String
    var name: String
    var url: String
}

let session = URLSession.shared
let url = URL(string: "https://rss.itunes.apple.com/api/v1/mx/apple-music/top-songs/all/25/explicit.json")!
var request = URLRequest(url: url)
request.httpMethod = "GET"
let task = session.dataTask(with: request) { (data, response, error) in
    if error == nil {
        if data != nil {
            do {
            /*let json = try JSONSerialization.jsonObject(with: data!, options: [])
                print(json)*/
                let feed = try decoder.decode([Result].self, from: data!)
            } catch {
                print(error.localizedDescription)
            }
        } else {
            print("No data")
        }
    } else {
        print(error!.localizedDescription)
    }
}
task.resume()
